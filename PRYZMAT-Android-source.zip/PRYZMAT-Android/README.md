# PRYZMAT Android
Natywna aplikacja Java na Androida, bez przeglądarki i bez WebView.

## Build APK
1. Utwórz nowe repozytorium GitHub i dodaj zawartość tego folderu (razem z `.github/workflows/apk.yml`).
2. GitHub Actions > PRYZMAT APK > Run workflow.
3. W zakończonym przebiegu pobierz artefakt `PRYZMAT-APK`, rozpakuj ZIP i zainstaluj `app-debug.apk` na telefonie.

Możesz również uruchomić projekt w Android Studio i wybrać Build > Build APK(s).

Wersja 0.1 działa offline. Dostępne są: ekran główny, zadania, notatki, ulubione tytuły, prosty dziennik PGN, timer i budżet. Automatyczne wiadomości, silnik szachowy i logowanie online nie są jeszcze zintegrowane.
