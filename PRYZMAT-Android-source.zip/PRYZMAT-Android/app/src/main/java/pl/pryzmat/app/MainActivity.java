package pl.pryzmat.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
  final int bg=0xff090716, panel=0xff19132c, purple=0xffa149ff, muted=0xffaea5c5, white=0xfff8f5ff;
  LinearLayout root,content; TextView clock; CountDownTimer timer; long remain=1500000; boolean running=false;
  android.content.SharedPreferences store;
  JSONArray tasks,notes; int tab=0;
  String[] titles={"Wistoria: Wand and Sword","MTEFIL","Blue Lock","Frieren","Hamilton","Hadestown","EPIC: The Musical","ILIUM","Ado","Teatr w Rzeszowie"};
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
    store=getSharedPreferences("pryzmat",MODE_PRIVATE);tasks=read("tasks");notes=read("notes");show(0);}
  JSONArray read(String key){try{return new JSONArray(store.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
  void save(){store.edit().putString("tasks",tasks.toString()).putString("notes",notes.toString()).apply();}
  int d(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
  TextView t(String s,int size,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(white);v.setTextSize(size);if(bold)v.setTypeface(null,1);return v;}
  GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(radius));g.setStroke(d(1),0xff40315d);return g;}
  LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  void add(LinearLayout l,View v,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=d(bottom);l.addView(v,p);}
  void section(String s){TextView x=t(s,20,true);x.setPadding(0,d(19),0,d(12));add(content,x,0);}
  void hint(String s){TextView x=t(s,13,false);x.setTextColor(muted);add(content,x,16);}
  LinearLayout card(){LinearLayout l=col();l.setPadding(d(16),d(15),d(16),d(15));l.setBackground(shape(panel,18));return l;}
  TextView action(String name,Runnable r){TextView a=t(name,14,true);a.setGravity(Gravity.CENTER);a.setPadding(d(14),d(13),d(14),d(13));a.setBackground(shape(0xff402467,13));a.setOnClickListener(v->r.run());return a;}
  void show(int page){tab=page;root=col();root.setBackgroundColor(bg);setContentView(root);
    TextView logo=t("◈  P R Y Z M A T",21,true);logo.setTextColor(0xffd5b6ff);logo.setPadding(d(22),d(19),d(12),d(17));add(root,logo,0);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);content=col();content.setPadding(d(20),d(5),d(20),d(24));scroll.addView(content);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    if(page==0)home();if(page==1)culture();if(page==2)chess();if(page==3)studio();if(page==4)life();
    LinearLayout nav=row();nav.setBackgroundColor(0xff161027);String[] items={"⌂\nStart","◈\nKultura","♞\nSzachy","✦\nStudio","▣\nŻycie"};
    for(int i=0;i<5;i++){final int n=i;TextView x=t(items[i],12,i==page);x.setGravity(Gravity.CENTER);x.setTextColor(i==page?0xffd5b6ff:muted);x.setPadding(0,d(10),0,d(10));nav.addView(x,new LinearLayout.LayoutParams(0,d(65),1));x.setOnClickListener(v->show(n));}root.addView(nav);}
  void header(String title,String subtitle){add(content,t(title,30,true),8);hint(subtitle);}
  void feature(String title,String desc,int page){LinearLayout x=card();add(x,t(title,17,true),5);TextView y=t(desc,12,false);y.setTextColor(muted);add(x,y,0);x.setOnClickListener(v->show(page));add(content,x,9);}
  void home(){header("Wszystkie twoje światy.","Jeden telefon. Zero chaosu. Prawie.");
    LinearLayout hero=card();hero.setBackground(shape(0xff5c23b2,22));add(hero,t("CENTRUM DOWODZENIA",11,true),14);add(hero,t("Twórz, odkrywaj, graj.",27,true),12);add(hero,action("+ Zapisz pomysł",()->noteEditor(-1)),0);add(content,hero,10);
    section("Twój PRYZMAT");feature("🎭  Kultura","Anime, manga, musicale i wydarzenia",1);feature("♞  Szachy","Szachownica i dziennik PGN",2);feature("✦  Studio","Scena, muzyka, cosplay, kod",3);feature("▣  Życie","Zadania, budżet i skupienie",4);
    section("Szybkie działania");add(content,action("+ Nowe zadanie",this::newTask),9);add(content,action("+ Nowa notatka",()->noteEditor(-1)),0);}
  void culture(){header("Kultura bez spoilerów.","Obserwuj wszystko, co uwielbiasz.");
    Switch sw=new Switch(this);sw.setText("Ochrona przed spoilerami");sw.setTextColor(white);sw.setChecked(store.getBoolean("shield",true));sw.setOnCheckedChangeListener((v,on)->store.edit().putBoolean("shield",on).apply());add(content,sw,14);
    section("Obserwowane tytuły");for(String name:titles){LinearLayout x=card();LinearLayout r=row();TextView label=t(name,15,true);r.addView(label,new LinearLayout.LayoutParams(0,-2,1));CheckBox check=new CheckBox(this);check.setButtonTintList(android.content.res.ColorStateList.valueOf(purple));check.setChecked(store.getBoolean("watch_"+name,false));check.setOnCheckedChangeListener((v,b)->store.edit().putBoolean("watch_"+name,b).apply());r.addView(check);x.addView(r);add(content,x,8);}
    hint("Monitorowanie premier i alerty internetowe będą wymagały integracji w kolejnej wersji.");}
  void chess(){header("Szachy.","Własny dziennik partii i analiza w przyszłości.");
    section("Szachownica demonstracyjna");String[] lines={"♜♞♝♛♚♝♞♜","♟♟♟♟♟♟♟♟","        ","        ","        ","        ","♙♙♙♙♙♙♙♙","♖♘♗♕♔♗♘♖"};
    LinearLayout board=col();int width=(getResources().getDisplayMetrics().widthPixels-d(40))/8;
    for(int y=0;y<8;y++){LinearLayout rank=row();for(int x=0;x<8;x++){TextView cell=t(String.valueOf(lines[y].charAt(x)),26,true);cell.setGravity(Gravity.CENTER);cell.setTextColor((x+y)%2==0?0xff271b35:white);cell.setBackgroundColor((x+y)%2==0?0xffb5a3d4:0xff594576);rank.addView(cell,new LinearLayout.LayoutParams(width,width));}board.addView(rank);}add(content,board,18);
    section("PGN");EditText field=new EditText(this);field.setTextColor(white);field.setHintTextColor(muted);field.setHint("Wklej zapis partii PGN");field.setMinLines(6);field.setText(store.getString("pgn",""));field.setBackground(shape(panel,12));field.setPadding(d(10),d(10),d(10),d(10));add(content,field,12);
    add(content,action("Zapisz PGN",()->{store.edit().putString("pgn",field.getText().toString()).apply();Toast.makeText(this,"Zapisano partię",0).show();}),10);
    add(content,action("Kopiuj PGN",()->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("PGN",field.getText()));Toast.makeText(this,"Skopiowano",0).show();}),0);
    hint("Szachownica jest podglądem, nie silnikiem szachowym. Stockfish i gra online nie są jeszcze zaimplementowane.");}
  void studio(){header("Studio twórcze.","Niech pomysły przestaną znikać.");section("Twoje projekty");
    feature("🎭  Aktorstwo","Role, spektakle i ćwiczenia",3);feature("♫  Muzyka","Skrzypce i własne utwory",3);feature("🎨  Cosplay","Stroje i projekty OC",3);feature("⌘  Programowanie","Lichess i nowe aplikacje",3);
    section("Notatnik");add(content,action("+ Nowy pomysł",()->noteEditor(-1)),12);
    for(int i=notes.length()-1;i>=0;i--){JSONObject obj=notes.optJSONObject(i);if(obj==null)continue;final int at=i;LinearLayout box=card();add(box,t(obj.optString("title"),16,true),7);TextView b=t(obj.optString("body"),12,false);b.setTextColor(muted);add(box,b,0);box.setOnClickListener(v->noteEditor(at));box.setOnLongClickListener(v->{remove(false,at);return true;});add(content,box,9);}hint("Dotknij notatki, aby edytować. Przytrzymaj, aby usunąć.");}
  void life(){header("Życie i szkoła.","Planuj, ucz się i odpoczywaj.");section("Zadania");add(content,action("+ Dodaj zadanie",this::newTask),12);
    for(int i=0;i<tasks.length();i++){JSONObject item=tasks.optJSONObject(i);if(item==null)continue;final int index=i;LinearLayout box=card();LinearLayout r=row();CheckBox ch=new CheckBox(this);ch.setButtonTintList(android.content.res.ColorStateList.valueOf(purple));ch.setChecked(item.optBoolean("done"));ch.setOnCheckedChangeListener((v,b)->{try{item.put("done",b);}catch(Exception e){}save();});r.addView(ch);TextView txt=t(item.optString("title"),14,false);r.addView(txt,new LinearLayout.LayoutParams(0,-2,1));TextView del=t("✕",20,true);del.setPadding(d(12),0,0,0);del.setOnClickListener(v->remove(true,index));r.addView(del);box.addView(r);add(content,box,7);}
    section("Tryb skupienia");clock=t(formatTime(remain),37,true);clock.setGravity(Gravity.CENTER);add(content,clock,12);
    add(content,action(running?"Pauza":"Start / wznów",()->{if(running){timer.cancel();running=false;show(4);}else{running=true;timer=new CountDownTimer(remain,1000){public void onTick(long ms){remain=ms;if(clock!=null)clock.setText(formatTime(ms));}public void onFinish(){remain=0;running=false;Toast.makeText(MainActivity.this,"Koniec skupienia!",1).show();show(4);}}.start();show(4);}}),8);
    add(content,action("Reset 25 minut",()->{if(timer!=null)timer.cancel();running=false;remain=1500000;show(4);}),8);
    section("Budżet");double spent=Double.longBitsToDouble(store.getLong("spent",Double.doubleToLongBits(0)));double cap=Double.longBitsToDouble(store.getLong("cap",Double.doubleToLongBits(500)));
    add(content,t(String.format(java.util.Locale.forLanguageTag("pl-PL"),"%.2f / %.2f zł",spent,cap),24,true),12);
    add(content,action("+ Wydatek",()->amount(false)),8);add(content,action("Ustaw limit",()->amount(true)),10);
    section("Twoje dane");add(content,action("Eksportuj kopię JSON",this::export),0);}
  String formatTime(long millis){long s=(millis+999)/1000;return String.format(java.util.Locale.ROOT,"%02d:%02d",s/60,s%60);}
  void newTask(){editText("Nowe zadanie","Co chcesz zrobić?","",(a,b)->{if(a.isEmpty())return;try{tasks.put(new JSONObject().put("title",a).put("done",false));}catch(Exception e){}save();show(tab);});}
  interface Saver{void save(String a,String b);}
  void editText(String heading,String h1,String prefill,Saver cb){EditText input=new EditText(this);input.setHint(h1);input.setSingleLine(true);input.setText(prefill);new AlertDialog.Builder(this).setTitle(heading).setView(input).setNegativeButton("Anuluj",null).setPositiveButton("Zapisz",(dialog,which)->cb.save(input.getText().toString().trim()," ")).show();}
  void noteEditor(int idx){JSONObject existing=idx<0?null:notes.optJSONObject(idx);LinearLayout fields=col();fields.setPadding(d(18),0,d(18),0);EditText name=new EditText(this);name.setHint("Tytuł");name.setSingleLine(true);EditText desc=new EditText(this);desc.setHint("Opis pomysłu");desc.setMinLines(4);if(existing!=null){name.setText(existing.optString("title"));desc.setText(existing.optString("body"));}add(fields,name,8);add(fields,desc,4);
    new AlertDialog.Builder(this).setTitle("Twój pomysł").setView(fields).setNegativeButton("Anuluj",null).setPositiveButton("Zapisz",(dlg,which)->{if(name.getText().toString().trim().isEmpty())return;try{JSONObject o=existing==null?new JSONObject():existing;o.put("title",name.getText().toString());o.put("body",desc.getText().toString());if(existing==null)notes.put(o);}catch(Exception e){}save();show(tab);}).show();}
  void remove(boolean task,int idx){new AlertDialog.Builder(this).setTitle("Usunąć wpis?").setNegativeButton("Anuluj",null).setPositiveButton("Usuń",(dialog,which)->{JSONArray src=task?tasks:notes,dst=new JSONArray();for(int i=0;i<src.length();i++)if(i!=idx)dst.put(src.opt(i));if(task)tasks=dst;else notes=dst;save();show(tab);}).show();}
  void amount(boolean limit){editText(limit?"Ustaw limit":"Dodaj wydatek","Kwota w złotych","",(a,b)->{try{double value=Double.parseDouble(a.replace(',','.'));if(value<=0||!Double.isFinite(value))throw new Exception();String key=limit?"cap":"spent";double current=Double.longBitsToDouble(store.getLong(key,Double.doubleToLongBits(0)));store.edit().putLong(key,Double.doubleToLongBits(limit?value:current+value)).apply();show(4);}catch(Exception e){Toast.makeText(this,"Nieprawidłowa kwota",0).show();}});}
  void export(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"pryzmat-kopia.json");startActivityForResult(i,11);}
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==11&&result==RESULT_OK&&data!=null&&data.getData()!=null)try{
      JSONObject out=new JSONObject();out.put("tasks",tasks);out.put("notes",notes);out.put("pgn",store.getString("pgn",""));JSONArray watched=new JSONArray();for(String title:titles)if(store.getBoolean("watch_"+title,false))watched.put(title);out.put("watched",watched);
      out.put("shield",store.getBoolean("shield",true));out.put("spent",Double.longBitsToDouble(store.getLong("spent",Double.doubleToLongBits(0))));out.put("cap",Double.longBitsToDouble(store.getLong("cap",Double.doubleToLongBits(500))));
      try(java.io.OutputStream s=getContentResolver().openOutputStream(data.getData())){s.write(out.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));}Toast.makeText(this,"Kopia zapisana",0).show();
    }catch(Exception e){Toast.makeText(this,"Nie udało się zapisać",0).show();}}
  @Override public void onBackPressed(){if(tab!=0)show(0);else super.onBackPressed();}
  @Override protected void onDestroy(){if(timer!=null)timer.cancel();super.onDestroy();}
}
